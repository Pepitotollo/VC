import pygame
import math

def draw_text_centered(screen, text, font, color, y_offset=0):
    text_surface = font.render(text, True, color)
    x = (screen.get_width() - text_surface.get_width()) // 2
    y = (screen.get_height() - text_surface.get_height()) // 2 + y_offset
    screen.blit(text_surface, (x, y))

def normalize_vector(dx, dy, speed):
    magnitude = math.sqrt(dx**2 + dy**2)
    if magnitude == 0:
        return 0, 0
    return (dx / magnitude) * speed, (dy / magnitude) * speed
