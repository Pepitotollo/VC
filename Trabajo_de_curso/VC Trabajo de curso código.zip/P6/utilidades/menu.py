import pygame
from utilidades.helpers import draw_text_centered
from juegos.pong import pong_game



WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
MENU_BACKGROUND_COLOR = (30, 30, 30)
font = pygame.font.SysFont(None, 80)
small_font = pygame.font.SysFont(None, 50)
SCREEN_WIDTH, SCREEN_HEIGHT = pygame.display.Info().current_w, pygame.display.Info().current_h
def main_menu():
    
    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.FULLSCREEN)
    while True:
        screen.fill(MENU_BACKGROUND_COLOR)
        draw_text_centered(screen, "Menú Principal", font, WHITE, -100)
        draw_text_centered(screen, "1. Un Jugador", small_font, WHITE, 0)
        draw_text_centered(screen, "2. Dos Jugadores", small_font, WHITE, 50)
        draw_text_centered(screen, "3. Salir", small_font, WHITE, 100)
        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_1:
                    return "one_player_menu"
                elif event.key == pygame.K_2:
                    return "two_players_menu"
                elif event.key == pygame.K_3:
                    pygame.quit()
                    exit()
            elif event.type == pygame.QUIT:
                pygame.quit()
                exit()

def one_player_menu():
    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.FULLSCREEN)
    while True:
        screen.fill(MENU_BACKGROUND_COLOR)
        draw_text_centered(screen, "Menú de Un Jugador", font, WHITE, -100)
        draw_text_centered(screen, "1. Juego Luz Verde, Luz Roja", small_font, WHITE, 0)
        draw_text_centered(screen, "2. Flappy", small_font, WHITE, 50)
        draw_text_centered(screen, "3. Hand Fist Dash", small_font, WHITE, 100)
        draw_text_centered(screen, "4. Regresar al Menú Principal", small_font, WHITE, 150)
        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_1:
                    return "juego_calamar"
                elif event.key == pygame.K_2:
                    return "flappy"
                elif event.key == pygame.K_3:
                    return "car"
                elif event.key == pygame.K_4:
                    return "main_menu"
            elif event.type == pygame.QUIT:
                pygame.quit()
                exit()

def two_players_menu():
    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.FULLSCREEN)
    while True:
        screen.fill(MENU_BACKGROUND_COLOR)
        draw_text_centered(screen, "Menú de Dos Jugadores", font, WHITE, -100)
        draw_text_centered(screen, "1. Pong", small_font, WHITE, 0)
        draw_text_centered(screen, "2. Regresar al Menú Principal", small_font, WHITE, 50)
        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_1:
                    return "pong"
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_2:
                    return "main_menu"
            elif event.type == pygame.QUIT:
                pygame.quit()
                exit()
