import pygame
import random
import time
import sys
import cv2
import mediapipe as mp

# Inicializar Pygame
pygame.init()

# Configuración de la ventana en pantalla completa
WIDTH, HEIGHT = pygame.display.Info().current_w, pygame.display.Info().current_h
screen = pygame.display.set_mode((WIDTH, HEIGHT), pygame.FULLSCREEN)
pygame.display.set_caption("Hand_Fist_Dash")
clock = pygame.time.Clock()

# Colores
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
CHROMA_GREEN = (0, 255, 0)

# Jugador
player_size = 60  # Tamaño del jugador
player_x = 100
player_y = HEIGHT - player_size - 20
player_jump = False
jump_speed = -18  # Incremento del salto
gravity = 1
player_velocity = 0
player_image = pygame.Surface((player_size, player_size))  # Superficie para el jugador

# Obstáculos
obstacle_width = 40  # Ancho del obstáculo
obstacle_height = 100  # Altura del obstáculo
obstacle_speed = 5
obstacles = []
obstacle_min_distance = 200  # Distancia mínima entre obstáculos
obstacle_max_distance = 400  # Distancia máxima entre obstáculos

# Fondo
background_speed = 2
initial_speed = 2
speed_increment = 0.01
background_image = pygame.image.load('fondo_arcade.png')
background_image = pygame.transform.scale(background_image, (WIDTH, HEIGHT))

# Configuración de Mediapipe para la detección de manos
mp_hands = mp.solutions.hands
hands = mp_hands.Hands(min_detection_confidence=0.7, min_tracking_confidence=0.7)
cap = cv2.VideoCapture(0)

# Función para detectar si la mano está abierta
def is_hand_open(results):
    if results.multi_hand_landmarks:
        for hand_landmarks in results.multi_hand_landmarks:
            fingers = []
            # Comprobamos si las y de los dedos 8, 12, 16 y 20 son menores que las bases correspondientes
            for i in [8, 12, 16, 20]:
                tip_y = hand_landmarks.landmark[i].y
                base_y = hand_landmarks.landmark[i - 2].y
                fingers.append(tip_y < base_y)
            return all(fingers)
    return False

# Función para mostrar las instrucciones iniciales
def show_instructions():
    screen.fill((135, 206, 250))  # Fondo colorido
    font = pygame.font.Font(None, 48)
    text = font.render("Pulsa cualquier tecla para comenzar.", True, BLACK)
    screen.blit(text, (WIDTH // 2 - text.get_width() // 2, HEIGHT // 2))
    pygame.display.flip()
    waiting = True
    while waiting:
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                waiting = False

# Menú de colisión
def collision_menu(time_survived):
    font = pygame.font.Font(None, 72)
    text_restart = font.render("Pulsa R para reiniciar", True, CHROMA_GREEN)
    text_exit = font.render("Pulsa Q para salir", True, CHROMA_GREEN)
    survived_text = font.render(f"Has aguantado {time_survived:.2f} segundos.", True, CHROMA_GREEN)
    screen.blit(text_restart, (WIDTH // 2 - text_restart.get_width() // 2, HEIGHT // 2 - 50))
    screen.blit(text_exit, (WIDTH // 2 - text_exit.get_width() // 2, HEIGHT // 2 + 10))
    screen.blit(survived_text, (WIDTH // 2 - survived_text.get_width() // 2, HEIGHT // 2 + 60))
    pygame.display.flip()

    while True:
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_r:
                    return "restart"
                elif event.key == pygame.K_q:
                    return "quit"

# Función para capturar una imagen al inicio y usarla como fondo del jugador
def capture_player_background():
    ret, frame = cap.read()
    if ret:
        # Captura la imagen de la cámara
        frame = cv2.flip(frame, 1)
        cv2.imwrite('captura_fondo.png', frame)  # Guardamos la imagen capturada
        player_background = pygame.image.load('captura_fondo.png')  # Cargamos la imagen como fondo del jugador
        return pygame.transform.scale(player_background, (player_size, player_size))  # Ajustamos el tamaño
    else:
        print("Error al capturar la imagen.")
        return None

# Función principal del juego
def carrera():
    global background_speed, player_y, player_jump, player_velocity, obstacles, obstacle_speed  # Declarar variables globales
    background_x = 0  # Inicialización de la variable aquí

    # Captura la imagen inicial para el fondo del jugador
    player_background_image = capture_player_background()
    if player_background_image is None:
        return  # Si no se puede capturar la imagen, terminamos el juego.

    # Reproducir música solo cuando inicie el juego
    pygame.mixer.music.load('musica_juego4.mp3')
    pygame.mixer.music.play(-1)  # Reproducir en bucle

    show_instructions()

    running = True
    hand_open = False  # Variable para evitar que el salto se active continuamente
    start_time = time.time()  # Iniciar el contador de tiempo

    while running:
        screen.fill(WHITE)

        # Capturar la imagen de la cámara
        ret, frame = cap.read()
        if not ret:
            break

        frame = cv2.flip(frame, 1)
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results = hands.process(rgb_frame)

        # Detectar gesto (si la mano está abierta)
        current_hand_open = is_hand_open(results)
        if current_hand_open and not hand_open:  # Si la mano se acaba de abrir
            if not player_jump:
                player_jump = True
                player_velocity = jump_speed
            hand_open = True  # Marcar que la mano está abierta

        elif not current_hand_open:  # Si la mano está cerrada
            hand_open = False  # Permitir que se detecte la siguiente apertura

        # Dibujar fondo desplazándose
        background_x -= background_speed
        if background_x <= -WIDTH:
            background_x = 0
        screen.blit(background_image, (background_x, 0))
        screen.blit(background_image, (background_x + WIDTH, 0))

        # Actualizar jugador
        if player_jump:
            player_velocity += gravity
            player_y += player_velocity
            if player_y >= HEIGHT - player_size - 20:
                player_y = HEIGHT - player_size - 20
                player_jump = False

        # Usamos la imagen de fondo del jugador capturada
        screen.blit(player_background_image, (player_x, player_y))

        # Generar obstáculos
        if len(obstacles) == 0 or obstacles[-1][0] < WIDTH - random.randint(obstacle_min_distance, obstacle_max_distance):
            obstacle_x = WIDTH
            obstacle_y = HEIGHT - obstacle_height - 20
            obstacle_h = random.randint(30, 70)
            obstacles.append([obstacle_x, obstacle_y, obstacle_h])

        # Dibujar y mover obstáculos
        for obstacle in obstacles[:]:
            obstacle[0] -= obstacle_speed
            pygame.draw.rect(screen, CHROMA_GREEN, (obstacle[0], obstacle[1] - (obstacle[2] - obstacle_height), obstacle_width, obstacle[2]))
            if obstacle[0] + obstacle_width < 0:
                obstacles.remove(obstacle)

        # Detección de colisiones
        player_rect = pygame.Rect(player_x, player_y, player_size, player_size)
        for obstacle in obstacles:
            obstacle_rect = pygame.Rect(obstacle[0], obstacle[1] - (obstacle[2] - obstacle_height), obstacle_width, obstacle[2])
            if player_rect.colliderect(obstacle_rect):
                time_survived = time.time() - start_time  # Calcular el tiempo que se ha sobrevivido
                choice = collision_menu(time_survived)
                if choice == "restart":
                    player_y = HEIGHT - player_size - 20
                    player_jump = False
                    player_velocity = 0
                    obstacles = []
                    background_x = 0
                    background_speed = initial_speed
                    obstacle_speed = 5
                    start_time = time.time()  # Reiniciar el contador de tiempo
                elif choice == "quit":
                    running = False

        # Incrementar velocidad progresivamente
        background_speed += speed_increment
        obstacle_speed += speed_increment

        # Actualizar pantalla
        pygame.display.flip()
        clock.tick(30)

    # Liberar recursos
    cap.release()
    pygame.quit()
    sys.exit()
