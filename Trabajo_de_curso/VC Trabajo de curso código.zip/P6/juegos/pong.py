import pygame
import cv2
import mediapipe as mp
import random
import time
import math
from utilidades.helpers import normalize_vector  # Importar función desde utilities
import sys

# Inicializar Pygame y MediaPipe
pygame.init()
mp_hands = mp.solutions.hands
mp_draw = mp.solutions.drawing_utils
hands = mp_hands.Hands(min_detection_confidence=0.7, min_tracking_confidence=0.5)

# Configuración de pantalla
SCREEN_WIDTH, SCREEN_HEIGHT = pygame.display.Info().current_w, pygame.display.Info().current_h
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.RESIZABLE)
pygame.display.set_caption("Juegos de Manos")

# Cargar sonidos
pygame.mixer.init()
bg_music = pygame.mixer.Sound('juegos/pongmusic.mp3')  # Música de fondo
goal_sound = pygame.mixer.Sound('juegos/goal.mp3')  # Sonido cuando hay un gol
wall_sound = pygame.mixer.Sound('juegos/wall.wav')  # Sonido cuando la pelota golpea la pared
bounce_sound = pygame.mixer.Sound('juegos/bounce.wav')  # Sonido cuando la pelota golpea la plataforma
bg_music.set_volume(0.1)
# Colores y fuentes
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
MENU_BACKGROUND_COLOR = (30, 30, 30)

font = pygame.font.SysFont(None, 80)
small_font = pygame.font.SysFont(None, 50)
big_font = pygame.font.SysFont(None, 150)  # Fuente grande para el contador

# Límites de la zona de juego
GAME_TOP = SCREEN_HEIGHT // 10
GAME_BOTTOM = SCREEN_HEIGHT - SCREEN_HEIGHT // 10

# Variables globales
clock = pygame.time.Clock()
FPS = 60

# Funciones de utilidad
def draw_text_centered(text, font, color, y_offset=0):
    text_surface = font.render(text, True, color)
    x = (SCREEN_WIDTH - text_surface.get_width()) // 2
    y = (SCREEN_HEIGHT - text_surface.get_height()) // 2 + y_offset
    screen.blit(text_surface, (x, y))

def show_countdown(seconds):
    """Muestra una cuenta regresiva en el centro de la pantalla."""
    for i in range(seconds, 0, -1):
        screen.fill(BLACK)
        countdown_text = f"{i}"
        draw_text_centered(countdown_text, big_font, WHITE, 0)
        pygame.display.flip()
        pygame.time.wait(1000)

def pause_menu():
    """Menú de pausa reutilizable."""
    while True:
        screen.fill(BLACK)
        draw_text_centered("Pausa", font, WHITE, -100)
        draw_text_centered("1. Continuar", small_font, WHITE, 0)
        draw_text_centered("2. Menú Principal", small_font, WHITE, 50)
        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_1:
                    return "continue"
                elif event.key == pygame.K_2:
                    return "menu"
            elif event.type == pygame.QUIT:
                pygame.quit()
                exit()

# Juego Pong
def pong_game():
    cap = cv2.VideoCapture(0)
    ball = {
        "x": SCREEN_WIDTH // 2,
        "y": SCREEN_HEIGHT // 2,
        "radius": 20,
        "dx": random.choice([-8, 8]),
        "dy": random.choice([-8, 8])
    }
    ball_speed = 12
    collision_count = 0
    score_1, score_2 = 0, 0

    # Reproducir música de fondo
    pygame.mixer.Sound.play(bg_music, loops=-1, maxtime=0)  # Repetir música indefinidamente

    def reset_ball():
        """Resetear la posición y velocidad de la pelota."""
        ball["x"] = SCREEN_WIDTH // 2
        ball["y"] = SCREEN_HEIGHT // 2
        ball["dx"] = random.choice([-8, 8])
        ball["dy"] = random.choice([-8, 8])
        return 12

    def show_goal_message(message):
        """Muestra un mensaje de gol en la pantalla."""
        screen.fill(BLACK)
        draw_text_centered(message, big_font, WHITE, 0)
        pygame.display.flip()
        pygame.time.wait(1000)

    running = True
    while running:
        ret, frame = cap.read()
        if not ret:
            break

        frame = cv2.flip(frame, 1)
        frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results = hands.process(frame_rgb)

        # Dibujar fondo del juego (cámara)
        frame_surface = pygame.surfarray.make_surface(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB).swapaxes(0, 1))
        frame_surface = pygame.transform.scale(frame_surface, (SCREEN_WIDTH, SCREEN_HEIGHT))
        screen.blit(frame_surface, (0, 0))

        # Dibujar bordes superiores e inferiores
        pygame.draw.rect(screen, MENU_BACKGROUND_COLOR, (0, 0, SCREEN_WIDTH, GAME_TOP))  # Borde superior
        pygame.draw.rect(screen, MENU_BACKGROUND_COLOR, (0, GAME_BOTTOM, SCREEN_WIDTH, SCREEN_HEIGHT - GAME_BOTTOM))  # Borde inferior

        # Dibujar marcador en la parte superior
        score_text = f"{score_1} - {score_2}"
        draw_text_centered(score_text, small_font, WHITE, -SCREEN_HEIGHT // 2 + GAME_TOP // 2)

        # Detectar manos y controlar plataformas
        left_hand_y, right_hand_y = None, None
        if results.multi_hand_landmarks:
            for hand_landmarks in results.multi_hand_landmarks:
                x = int(hand_landmarks.landmark[8].x * SCREEN_WIDTH)
                y = int(hand_landmarks.landmark[8].y * SCREEN_HEIGHT)
                if x < SCREEN_WIDTH // 2:
                    left_hand_y = max(GAME_TOP + 50, min(GAME_BOTTOM - 50, y))  # Dentro del área de juego
                else:
                    right_hand_y = max(GAME_TOP + 50, min(GAME_BOTTOM - 50, y))  # Dentro del área de juego

        # Dibujar plataformas
        if left_hand_y is not None:
            pygame.draw.rect(screen, GREEN, (50, left_hand_y - 50, 20, 100))  # Plataforma izquierda (Verde)
        if right_hand_y is not None:
            pygame.draw.rect(screen, BLUE, (SCREEN_WIDTH - 70, right_hand_y - 50, 20, 100))  # Plataforma derecha (Azul)

        # Movimiento de la pelota
        ball["x"] += ball["dx"]
        ball["y"] += ball["dy"]

        # Rebote contra los bordes superior e inferior
        if ball["y"] - ball["radius"] <= GAME_TOP or ball["y"] + ball["radius"] >= GAME_BOTTOM:
            ball["dy"] *= -1
            pygame.mixer.Sound.play(wall_sound)  # Reproducir sonido de rebote en la pared

        # Colisión con plataformas
        if left_hand_y and 50 < ball["x"] - ball["radius"] < 70 and left_hand_y - 50 < ball["y"] < left_hand_y + 50:
            ball["dx"] = abs(ball["dx"])
            collision_count += 1
            pygame.mixer.Sound.play(bounce_sound)  # Reproducir sonido de rebote en plataforma
        if right_hand_y and SCREEN_WIDTH - 70 < ball["x"] + ball["radius"] < SCREEN_WIDTH - 50 and right_hand_y - 50 < ball["y"] < right_hand_y + 50:
            ball["dx"] = -abs(ball["dx"])
            collision_count += 1
            pygame.mixer.Sound.play(bounce_sound)  # Reproducir sonido de rebote en plataforma

        # Incrementar velocidad de la bola después de 3 colisiones
        if collision_count > 0 and collision_count % 3 == 0:
            ball_speed += 1
            ball["dx"], ball["dy"] = normalize_vector(ball["dx"], ball["dy"], ball_speed)
            collision_count = 0

        # Gol del jugador 2
        if ball["x"] - ball["radius"] < 0:
            score_2 += 1
            pygame.mixer.Sound.play(goal_sound)  # Reproducir sonido de gol
            show_goal_message("Jugador 2 anotó!")
            show_countdown(3)
            ball_speed = reset_ball()

        # Gol del jugador 1
        elif ball["x"] + ball["radius"] > SCREEN_WIDTH:
            score_1 += 1
            pygame.mixer.Sound.play(goal_sound)  # Reproducir sonido de gol
            show_goal_message("Jugador 1 anotó!")
            show_countdown(3)
            ball_speed = reset_ball()

        # Detectar tecla ESC para pausa
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                if pause_menu() == "menu":
                    pygame.mixer.Sound.stop(bg_music)  # Detener la música al salir
                    return  # Regresar al menú principal

        # Dibujar la pelota
        pygame.draw.circle(screen, RED, (ball["x"], ball["y"]), ball["radius"])

        # Actualizar pantalla
        pygame.display.flip()
        clock.tick(FPS)

    cap.release()

# Menús y ciclo principal
def main_menu():
    while True:
        screen.fill(MENU_BACKGROUND_COLOR)
        draw_text_centered("Menú Principal", font, WHITE, -100)
        draw_text_centered("1. Pong", small_font, WHITE, 0)
        draw_text_centered("2. Salir", small_font, WHITE, 50)
        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_1:
                    show_countdown(3)
                    pong_game()
                elif event.key == pygame.K_2:
                    pygame.quit()
                    exit()
            elif event.type == pygame.QUIT:
                pygame.quit()
                exit()

if __name__ == "__main__":
    main_menu()
