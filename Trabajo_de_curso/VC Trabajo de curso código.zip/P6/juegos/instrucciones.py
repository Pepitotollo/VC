import pygame
from utilidades.helpers import draw_text_centered
from juegos.pong import pong_game
from juegos.juego_calamar import cal_game
from juegos.flappy import game_loop

WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
MENU_BACKGROUND_COLOR = (30, 30, 30)

SCREEN_WIDTH, SCREEN_HEIGHT = pygame.display.Info().current_w, pygame.display.Info().current_h

GAME_TOP = SCREEN_HEIGHT // 10
GAME_BOTTOM = SCREEN_HEIGHT - SCREEN_HEIGHT // 10
def show_instructions_calamar():
    """
    Muestra las instrucciones del juego 'Luz Verde, Luz Roja' y lanza el juego después de presionar una tecla.
    """
    pygame.init()
    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.FULLSCREEN)
    screen.fill(BLACK)
    instructions = [
        "¡Bienvenido al juego 'Luz Verde, Luz Roja'!",
        "1. Cuando la luz esté verde, debes parpadear para ganar puntos.",
        "2. Si parpadeas mientras la luz está roja, pierdes.",
        "3. Completa la barra de progreso para ganar.",
        "Presiona cualquier tecla para comenzar."
    ]
    font = pygame.font.SysFont(None, 40)

    for i, line in enumerate(instructions):
        text_surface = font.render(line, True, WHITE)
        screen.blit(text_surface, (SCREEN_WIDTH // 2 - text_surface.get_width() // 2, SCREEN_HEIGHT // 2 - 100 + i * 40))

    pygame.display.flip()
    waiting = True
    while waiting:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if event.type == pygame.KEYDOWN:
                waiting = False

    cal_game()  # Llama al juego

def show_instructions_flapy():
    """
    Muestra las instrucciones del juego 'Luz Verde, Luz Roja' y lanza el juego después de presionar una tecla.
    """
    pygame.init()
    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.FULLSCREEN)
    screen.fill(BLACK)
    instructions = [
        "¡Bienvenido al juego 'Flappy'!",
        "1. Mueve la cabeza para esquivar los obstaculos.",
        "2. Si te chocas contra algun obstaculo pierdes.",
        "3. Llega los más lejos posible.",
        "Presiona cualquier tecla para comenzar."
    ]
    font = pygame.font.SysFont(None, 40)

    for i, line in enumerate(instructions):
        text_surface = font.render(line, True, WHITE)
        screen.blit(text_surface, (SCREEN_WIDTH // 2 - text_surface.get_width() // 2, SCREEN_HEIGHT // 2 - 100 + i * 40))

    pygame.display.flip()
    waiting = True
    while waiting:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if event.type == pygame.KEYDOWN:
                waiting = False

    game_loop() # Llama al juego



def show_instructions_pong():
    """
    Muestra las instrucciones del juego 'Pong' y lanza el juego después de presionar una tecla.
    """
    pygame.init()
    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.FULLSCREEN)
    screen.fill(BLACK)
    instructions = [
        "¡Bienvenido al juego 'Pong'!",
        "1. Juega con un amigo.",
        "2. El jugador de la izquierda usa su mano para mover la barra, en su mitad de la pantalla",
        "3. El jugador de la derecha usa su mano para mover la barra, en su mitad de la pantalla",
        "Presiona cualquier tecla para comenzar."
    ]
    font = pygame.font.SysFont(None, 40)
    
    for i, line in enumerate(instructions):
        text_surface = font.render(line, True, WHITE)
        screen.blit(text_surface, (SCREEN_WIDTH // 2 - text_surface.get_width() // 2, SCREEN_HEIGHT // 2 - 100 + i * 40))
    pygame.draw.rect(screen, GREEN, (100, GAME_TOP, (SCREEN_WIDTH // 2) - 150, GAME_BOTTOM - GAME_TOP), 5)  # Cuadro izquierdo
    pygame.draw.rect(screen, RED, ((SCREEN_WIDTH // 2) + 50, GAME_TOP, (SCREEN_WIDTH // 2) - 150, GAME_BOTTOM - GAME_TOP), 5)  # Cuadro derecho
    pygame.display.flip()
    waiting = True
    while waiting:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if event.type == pygame.KEYDOWN:
                waiting = False

    pong_game()  # Llama al juego
