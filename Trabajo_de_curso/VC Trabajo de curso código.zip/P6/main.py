import pygame
from juegos.pong import pong_game
from juegos.juego_calamar import cal_game
from juegos.dash import carrera
from juegos.instrucciones import show_instructions_pong, show_instructions_calamar, show_instructions_flapy
#from juegos.carrera import carrera
pygame.init()
from utilidades.helpers import *
from utilidades.menu import main_menu, one_player_menu, two_players_menu
def main():
    while True:
        menu_selection = main_menu()
        if menu_selection == "one_player_menu":
            game_selection = one_player_menu()
            if game_selection=="juego_calamar":
                show_instructions_calamar()
            if game_selection=="flappy":
                show_instructions_flapy()
            if game_selection=="car":
                carrera()
            # Aquí puedes cargar juegos de un jugador en el futuro
        elif menu_selection == "two_players_menu":
            game_selection = two_players_menu()
            if game_selection=="pong":
                show_instructions_pong()

if __name__ == "__main__":
    try:
        main()
    except SystemExit:
        pygame.quit()
